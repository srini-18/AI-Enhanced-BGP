# bgp-sim — Real-Time Simulation Engine

A standalone **Bun + Socket.IO** service that implements the AI-Enhanced BGP
control-plane logic as a live, tick-driven simulation. The Next.js webapp
(`../webapp`) is its operator front end.

## What it simulates

| Subsystem | Implementation |
| --- | --- |
| Topology | 10-AS multi-tier hierarchy (AS65001–AS65010), provider/customer/peer edges, business-relationship valley-free rules |
| Telemetry | Synthetic BGP announcements with configurable false-positive rate and noise floor |
| Feature extractor | All 10 behavioral features (AS-path length, edit distance, origin-AS change, prefix mask length, announcements/min, flap count, local-pref, route age, valley-free violation, neighbor diversity) |
| ML classifier | Random Forest or Logistic Regression, 4 classes (Normal / Suspicious / Route Leak / Prefix Hijack), sensitivity + training knobs |
| Trust engine | Weighted multi-criteria score (origin 0.20 · path 0.20 · flap 0.15 · prefix 0.15 · peer 0.10 · ML 0.20 — all editable) |
| Policy actor | Trust-tier → local-pref mapping (100 / 80 / 50 / 0 + `no-export` quarantine) with threshold bands |
| Shadow validation | Streak-based promotion, hijack fast-path quarantine, dwell timer |
| Rollback engine | N consecutive normal ticks → automatic LP 100 restoration |
| Scenarios | S1–S6 (direct hijack, sub-prefix /25, flapping, YouTube 2008, Google 2017 leak, Cloudflare 2019 leak) + custom attack builder |
| Ablations | A0–A4 variants (standard BGP → full system), per-subsystem enable flags |

## Run

```bash
bun install
bun run dev        # starts on port 3010 with hot reload
```

The engine exposes **Socket.IO on port 3010, path `/`**.

## Socket API

The server broadcasts:

- `sim:state` — full state snapshot every tick (800 ms default): routes,
  trust scores, RIB, events, metrics, config echo
- `event:new` — append-only event log entry

The server accepts:

- `sim:start` / `sim:pause` / `sim:reset` / `sim:tick`
- `attack:inject { scenarioId }` / `attack:withdraw { prefix }` /
  `attack:custom { spec }`
- `scenarios:list`
- `config:reset` / `config:preset { id }` / `config:update { patch }` —
  deep-merges any subset of the simulation config; every subsystem flag,
  weight, threshold and timer is editable at runtime
