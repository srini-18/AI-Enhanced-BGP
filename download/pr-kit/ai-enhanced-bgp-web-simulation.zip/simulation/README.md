# 🖥️ AI-Enhanced BGP — Interactive Web Simulation

[![Next.js 16](https://img.shields.io/badge/Next.js-16-black.svg)](https://nextjs.org/)
[![Bun](https://img.shields.io/badge/runtime-Bun-f472b6.svg)](https://bun.com/)
[![Socket.IO](https://img.shields.io/badge/realtime-Socket.IO-010101.svg)](https://socket.io/)
[![Prisma](https://img.shields.io/badge/db-Prisma%20%2B%20SQLite-2d3748.svg)](https://www.prisma.io/)

A real-time, fully-interactive operator **NOC ("Control Room") for the
AI-Enhanced BGP autonomous control plane**. Every subsystem of the research
pipeline — telemetry, feature extraction, ML classification, the hybrid trust
engine, policy actioning, shadow validation, and rollback — can be
**toggled on/off and tuned live** while the simulation runs, making it an
interactive companion to the paper's A0–A4 ablation matrix and S1–S6 attack
scenarios.

| Control Room | Analytics |
| --- | --- |
| ![Control Room](docs/img/control-room.png) | ![Analytics](docs/img/analytics.png) |

---

## ✨ What you can do

- **Live 10-AS topology** — animated force-graph of AS65001–AS65010 with
  attack paths, quarantine badges and per-AS drilldown
- **Run the six canonical attack scenarios** (S1 direct hijack · S2 sub-prefix
  /25 · S3 flapping · S4 YouTube 2008 · S5 Google 2017 leak · S6 Cloudflare
  2019 leak) **or build a custom attack** (prefix, origin AS, path length,
  flap rate, leak shape)
- **Every knob editable at runtime**: ML model choice (RF / LogReg), trust
  weights (Σ must equal 1.0), policy tier thresholds, shadow streak & dwell,
  rollback ticks, telemetry FPR/noise — with live config-diff vs. the A4
  baseline
- **A/B auto-benchmark** — run the same scenario across two defense variants
  and compare MTTD / MTTM / mitigation-success / RIB-verification
- **Ablation Lab** — one-click A0–A4 variant runs with a survival-style
  results matrix
- **Chaos drills** — randomized scenario batteries with optional **config
  fuzz** (defense knobs randomized per round, snapshot-restored after)
- **Prefix drilldown & forensics** — per-prefix evidence trail, printable
  incident report (browser print → PDF)
- **Per-prefix watchlist** — star any route; status/trust-tier transitions
  raise toasts, sound and visual alerts
- **Time-travel replay** — scrub through the event history of a run
- **AI Copilot** — an LLM assistant that explains what the defense system is
  doing and answers operator questions about current state
- **Persistence** — run archive (SQLite via Prisma) with KPI history,
  presets for defense configs, full event-log export

## 🏗️ Architecture

```
┌────────────────────────────┐        Socket.IO (path /, 800ms ticks)
│  engine/   (Bun, port 3010)│◄──────────────────────────────┐
│  · topology + valley-free  │   sim:state / event:new        │
│  · 10-feature extractor    │───────────────────────────────►│
│  · ML classifier (RF/LR)   │   attack:inject · config:update│
│  · trust engine (Σw = 1.0) │   sim:start/pause/reset …      │
│  · policy actor + shadow   │                                │
│  · rollback engine         │        ┌───────────────────────┴──┐
└────────────────────────────┘        │  webapp/  (Next.js :3000) │
     SQLite (runs, presets) ◄───────── │  · control room + RIB     │
        via REST /api/sim-runs         │  · analytics (recharts)   │
        /api/sim-presets               │  · benchmark · copilot    │
                                      └───────────────────────────┘
```

## 🚀 Quickstart

Prerequisites: [Bun](https://bun.com/) ≥ 1.1.

```bash
# 1. start the simulation engine
cd simulation/engine
bun install
bun run dev                 # Socket.IO on :3010

# 2. start the web app (second terminal)
cd ../webapp
bun install
cp .env.example .env        # DATABASE_URL for the run archive
bunx prisma db push         # create the SQLite schema
bun run dev                 # http://localhost:3000
```

The webapp connects to the engine through same-origin `/?XTransformPort=3010`
(reverse-proxy mode). For a direct two-process deployment set:

```bash
NEXT_PUBLIC_BGP_SIM_URL=http://localhost:3010
```

in `webapp/.env` (engine CORS is open on localhost) — see
`webapp/src/lib/bgp-sim/client.ts`.

## 🗺️ Research-concept → feature mapping

| Research concept (repo root) | Web simulation |
| --- | --- |
| 10-AS topology / Gao-Rexford | Topology graph + valley-free feature & policy guard |
| 10-feature behavioral extractor | Live per-announcement feature panel |
| Calibrated ML (4 classes) | Classifier card: model, sensitivity, class mix |
| Hybrid trust engine (6 criteria) | Trust radar + weights editor (Σ=1.0 enforced) |
| Policy tiers LP 100/80/50/0 | Route-map preview + RIB local-pref column |
| Shadow validation + anti-thrash | Streak / dwell controls + quarantine badges |
| Multi-criteria rollback | Rollback ticks control + LP restoration events |
| S1–S6 scenarios | Attack panel one-click injection |
| A0–A4 ablation matrix | Ablation Lab + auto-benchmark A/B |
| MTTD / MTTM / MSR / RIB check | KPI header + benchmark result cards |
| 12-week plan artifacts | Docs tab (architecture explainer) |

## ⌨️ Operator conveniences

Keyboard shortcuts (`?` cheat-sheet), sound alert modes (siren / chime / mute),
dark control-room theme, mobile-responsive down to 390px, toast + watchlist
alert history, CSV/HTML/JSON export of runs, printable forensic reports.

## 📄 License

MIT — same as the parent repository.
